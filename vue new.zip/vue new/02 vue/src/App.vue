<template>
  <h1>Componentes</h1>
  <hr>
  <Card url="https://cdn.svgporn.com/logos/vue.svg?response-content-disposition=attachment%3Bfilename%3Dvue.svg" />
  <Card/>
  <Card/>
</template>

<script>
import Card from '../componentes/Card.vue';
export default {
  components: {Card}
}
</script>
